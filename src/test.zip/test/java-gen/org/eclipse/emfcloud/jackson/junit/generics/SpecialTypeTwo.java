/**
 */
package org.eclipse.emfcloud.jackson.junit.generics;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Special Type Two</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.emfcloud.jackson.junit.generics.GenericsPackage#getSpecialTypeTwo()
 * @model superTypes="org.eclipse.emfcloud.jackson.junit.generics.GenericType&lt;org.eclipse.emf.ecore.EBooleanObject&gt;"
 * @generated
 */
public interface SpecialTypeTwo extends GenericType<Boolean> {
} // SpecialTypeTwo
