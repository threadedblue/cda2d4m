/**
 */
package org.eclipse.emfcloud.jackson.junit.annotations;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Foo Type Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.emfcloud.jackson.junit.annotations.AnnotationsPackage#getFooTypeClass()
 * @model
 * @generated
 */
public interface FooTypeClass extends TestTypeClass {
} // FooTypeClass
