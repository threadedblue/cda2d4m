/**
 */
package org.eclipse.emfcloud.jackson.junit.packageAnnotations;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Bar Type Name</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.emfcloud.jackson.junit.packageAnnotations.PackageAnnotationsPackage#getBarTypeName()
 * @model
 * @generated
 */
public interface BarTypeName extends TestTypeName {
} // BarTypeName
