/**
 */
package org.eclipse.emfcloud.jackson.junit.annotations;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Bar Type Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.emfcloud.jackson.junit.annotations.AnnotationsPackage#getBarTypeClass()
 * @model
 * @generated
 */
public interface BarTypeClass extends TestTypeClass {
} // BarTypeClass
