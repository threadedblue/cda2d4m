/**
 */
package org.eclipse.emfcloud.jackson.junit.generics;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Base One</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.emfcloud.jackson.junit.generics.GenericsPackage#getBaseOne()
 * @model
 * @generated
 */
public interface BaseOne extends Base<Some, Any> {
} // BaseOne
