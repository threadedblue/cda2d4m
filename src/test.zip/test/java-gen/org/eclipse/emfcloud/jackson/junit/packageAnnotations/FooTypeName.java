/**
 */
package org.eclipse.emfcloud.jackson.junit.packageAnnotations;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Foo Type Name</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.emfcloud.jackson.junit.packageAnnotations.PackageAnnotationsPackage#getFooTypeName()
 * @model
 * @generated
 */
public interface FooTypeName extends TestTypeName {
} // FooTypeName
