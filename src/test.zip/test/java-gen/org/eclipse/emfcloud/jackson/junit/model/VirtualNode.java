/**
 */
package org.eclipse.emfcloud.jackson.junit.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Virtual Node</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.emfcloud.jackson.junit.model.ModelPackage#getVirtualNode()
 * @model
 * @generated
 */
public interface VirtualNode extends AbstractNode {
} // VirtualNode
