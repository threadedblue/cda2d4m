/**
 */
package org.eclipse.emfcloud.jackson.junit.annotations.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emfcloud.jackson.junit.annotations.AnnotationsPackage;
import org.eclipse.emfcloud.jackson.junit.annotations.BarTypeClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Bar Type Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class BarTypeClassImpl extends TestTypeClassImpl implements BarTypeClass {
   /**
    * <!-- begin-user-doc -->
    * <!-- end-user-doc -->
    * @generated
    */
   protected BarTypeClassImpl() {
      super();
   }

   /**
    * <!-- begin-user-doc -->
    * <!-- end-user-doc -->
    * @generated
    */
   @Override
   protected EClass eStaticClass() {
      return AnnotationsPackage.Literals.BAR_TYPE_CLASS;
   }

} //BarTypeClassImpl
