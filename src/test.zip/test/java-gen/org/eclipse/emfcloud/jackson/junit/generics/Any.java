/**
 */
package org.eclipse.emfcloud.jackson.junit.generics;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Any</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.emfcloud.jackson.junit.generics.GenericsPackage#getAny()
 * @model
 * @generated
 */
public interface Any extends EObject {
} // Any
