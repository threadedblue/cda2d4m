/**
 */
package org.eclipse.emfcloud.jackson.junit.generics.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emfcloud.jackson.junit.generics.GenericsPackage;
import org.eclipse.emfcloud.jackson.junit.generics.Some;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Some</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SomeImpl extends MinimalEObjectImpl implements Some {
   /**
    * <!-- begin-user-doc -->
    * <!-- end-user-doc -->
    * @generated
    */
   protected SomeImpl() {
      super();
   }

   /**
    * <!-- begin-user-doc -->
    * <!-- end-user-doc -->
    * @generated
    */
   @Override
   protected EClass eStaticClass() {
      return GenericsPackage.Literals.SOME;
   }

} //SomeImpl
