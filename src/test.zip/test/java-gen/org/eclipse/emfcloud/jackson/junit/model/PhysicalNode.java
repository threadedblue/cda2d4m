/**
 */
package org.eclipse.emfcloud.jackson.junit.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Physical Node</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.emfcloud.jackson.junit.model.ModelPackage#getPhysicalNode()
 * @model
 * @generated
 */
public interface PhysicalNode extends AbstractNode {
} // PhysicalNode
