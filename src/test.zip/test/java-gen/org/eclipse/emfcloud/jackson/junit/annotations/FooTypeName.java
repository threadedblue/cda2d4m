/**
 */
package org.eclipse.emfcloud.jackson.junit.annotations;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Foo Type Name</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.emfcloud.jackson.junit.annotations.AnnotationsPackage#getFooTypeName()
 * @model
 * @generated
 */
public interface FooTypeName extends TestTypeName {
} // FooTypeName
