/**
 */
package org.eclipse.emfcloud.jackson.junit.packageAnnotations.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emfcloud.jackson.junit.packageAnnotations.BarTypeName;
import org.eclipse.emfcloud.jackson.junit.packageAnnotations.PackageAnnotationsPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Bar Type Name</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class BarTypeNameImpl extends TestTypeNameImpl implements BarTypeName {
   /**
    * <!-- begin-user-doc -->
    * <!-- end-user-doc -->
    * @generated
    */
   protected BarTypeNameImpl() {
      super();
   }

   /**
    * <!-- begin-user-doc -->
    * <!-- end-user-doc -->
    * @generated
    */
   @Override
   protected EClass eStaticClass() {
      return PackageAnnotationsPackage.Literals.BAR_TYPE_NAME;
   }

} //BarTypeNameImpl
