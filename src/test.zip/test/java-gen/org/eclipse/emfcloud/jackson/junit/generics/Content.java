/**
 */
package org.eclipse.emfcloud.jackson.junit.generics;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Content</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.emfcloud.jackson.junit.generics.GenericsPackage#getContent()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface Content extends EObject {
} // Content
