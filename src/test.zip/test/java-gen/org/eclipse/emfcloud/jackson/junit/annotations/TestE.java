/**
 */
package org.eclipse.emfcloud.jackson.junit.annotations;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Test E</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.emfcloud.jackson.junit.annotations.AnnotationsPackage#getTestE()
 * @model annotation="JsonType property='@foo'"
 * @generated
 */
public interface TestE extends TestD {
} // TestE
